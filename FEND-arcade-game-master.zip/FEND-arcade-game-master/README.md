# Classic Arcade Game Clone Project

This is a classic 2D arcade game with the goal of getting the player to the other side. The starter code was provided  by Udacity and some of the starter code was explained on Udacity discussions [forum](https://discussions.udacity.com/t/i-dont-understand-how-to-code-classic-arcade-game/527836). 

## How to Run

To run the application, please download the Zip file or clone it to your machine. Upon completion, you can click on index.html to run the game. 

## How to Play

Press the up, down, left, right arrow keys to control the movement of the player. The objective is to guide the frogger to the water. Each player has 3 lives to get the frogger across. 

